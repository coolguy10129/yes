declare module "*.template.html" {
    const value: string;
    export = value;
}
