# Subway Surfers in your VS Code

## To activate this extension use the `This code boring ah hell 💀` command from the command palette (`Ctrl + Shift + P` / `⇧ ⌘ P`)

![VS Code Subway Surfers](https://i.imgur.com/IAYr09o.png)


## Many thanks to

- [@Abb1x](https://github.com/Abb1x) for adding Minecraft parkour videos!
- [@styxpilled](https://github.com/styxpilled) for adding Better Call Saul best moments
- [@paolomartinez](https://github.com/paolomartinez) for adding Family Guy best moments
